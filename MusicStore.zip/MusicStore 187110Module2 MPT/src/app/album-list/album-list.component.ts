import { Component, OnInit } from '@angular/core';
import { MusicService, MusicStore } from '../music.service';

@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {
service:MusicService;
  constructor(service:MusicService) {
    this.service=service;
   }
music:MusicStore[]=[];

delete(e)
  {
    let index = this.music.indexOf(e);
    this.music.splice(index,1);
    
  }
  ngOnInit() {
    this.service.fetchDetails();
    this.music=this.service.getStore();
  }

}
